# Prettier + commitlint + lint-staged + husky templates

## .prettierrc.json  (match existing code style to avoid first-format diff)
```json
{
  "semi": true,
  "singleQuote": true,
  "trailingComma": "all",
  "printWidth": 100,
  "tabWidth": 2,
  "arrowParens": "always",
  "bracketSpacing": true,
  "jsxSingleQuote": false
}
```

## .prettierignore
```
dist
node_modules
coverage
package-lock.json
*.md
```

## commitlint.config.js  (ESM; project "type": "module")
```js
export default {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [2, 'always', [
      'feat','fix','docs','style','refactor','perf','test','build','ci','chore','revert'
    ]],
    'scope-enum': [2, 'always', [
      'engine','rules','dictionary','config','ui','share','storage','deps','ci','release'
    ]],
    'subject-max-length': [2, 'always', 100],
  },
};
```
> Replace `scope-enum` with the project's actual module names.

## .lintstagedrc.json
```json
{
  "*.{ts,tsx}": ["eslint --fix", "prettier --write"],
  "*.{json,css,html,md,yml,yaml}": ["prettier --write"]
}
```

## .husky/pre-commit   (chmod +x)
```sh
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"
npx --no-install lint-staged
```

## .husky/commit-msg   (chmod +x)
```sh
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"
npx --no-install commitlint --edit "$1"
```

## package.json scripts / devDeps
```jsonc
"scripts": {
  "lint": "eslint .",
  "lint:fix": "eslint . --fix",
  "format": "prettier --write .",
  "format:check": "prettier --check .",
  "typecheck": "tsc --noEmit",
  "test:cov": "vitest run --coverage",
  "prepare": "husky"
},
"devDependencies": {
  "@commitlint/cli": "^19.6.1",
  "@commitlint/config-conventional": "^19.6.0",
  "@eslint/js": "^9.17.0",
  "@vitest/coverage-v8": "^2.1.8",
  "eslint": "^9.17.0",
  "eslint-plugin-react-hooks": "^5.1.0",
  "eslint-plugin-react-refresh": "^0.4.16",
  "globals": "^15.14.0",
  "husky": "^9.1.7",
  "lint-staged": "^15.2.11",
  "prettier": "^3.4.2",
  "typescript-eslint": "^8.18.0"
}
```

## vitest.config.ts coverage gate
```ts
test: {
  environment: 'node',
  include: ['tests/**/*.test.ts'],
  coverage: {
    provider: 'v8',
    reporter: ['text', 'html', 'lcov'],
    include: ['src/**/*.{ts,tsx}'],
    exclude: ['src/main.tsx', 'src/vite-env.d.ts', 'src/index.css'],
    thresholds: { statements: 80, branches: 75, functions: 80, lines: 80 },
  },
}
```
