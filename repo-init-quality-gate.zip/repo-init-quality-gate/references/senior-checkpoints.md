# Senior-developer intervention checkpoints (template — adapt to project)

## Mandatory sign-off files (any change touches these → senior review)
- Determinism / core algorithm (e.g. `engine/determinism.ts`, `engine/pipeline.ts`)
- Config model that feeds serialization/seed (e.g. `config/schema.ts`)
- Public contract / types (e.g. `engine/index.ts`, `engine/types.ts`)
- Cross-module state (e.g. `config/store.ts`, `ui/store.ts`)
- Rule / dictionary logic (e.g. `rules/*`, `dictionary/*`)
- Dependency add/upgrade (`package.json` `dependencies`, scope `deps`)
- Performance-sensitive paths (chunking, canvas render)

## Architecture-review triggers (any one → review)
1. New language direction / breaking an existing closed loop.
2. Any runtime network dependency (breaks "no-network" rule → senior + privacy review).
3. New / refactored rule family or structural change to rule set.
4. Storage-layer change (IndexedDB ↔ other, remote sync).
5. Render/share path change (non-Canvas, new UI framework).
6. Performance budget breach (build size +20%, first-paint regression).
7. Cross-repo / public API exposure.

## Review checklist (every senior review)
- [ ] Determinism unaffected (reproducibility still 100%).
- [ ] Round-trip restore rate preserved (regression suite green).
- [ ] No new `console.*`, no `any` abuse, no `Math.random` leaking into engine.
- [ ] Types strict (`tsc --noEmit` 0 errors); new logic has tests.
- [ ] No network dependency introduced; theme (dark mode) unaffected.
- [ ] Within performance budget.
