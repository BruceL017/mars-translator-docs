---
name: repo-init-quality-gate
description: "Scaffold engineering-quality tooling (ESLint 9 flat config, Prettier, commitlint, husky plus lint-staged, Vitest coverage gate, CI workflow, editorconfig/nvmrc/gitignore) for a TypeScript or Vite project after a repo scan. Use when the user asks to scan a repo and set up or initialize code standards, lint or format configs, commit conventions, quality gates, or CI, including generating an init config that documents tech stack, quality gates, team skill paths, and senior-developer review checkpoints."
agent_created: true
---

# Repo Init · Quality Gate Scaffold

Bootstrap engineering-process tooling for a frontend/TS project that has working feature code
but no engineering baseline (no git, no lint/format, no commit convention, no CI).

## When to use

- User asks to scan a local repo and generate an **init config**: tech stack overview, code
  standards / quality gates (ESLint, Prettier, commitlint…), team skill-improvement path,
  senior-developer intervention checkpoints, and CI init advice.
- A project is delivered but lacks ESLint/Prettier/husky/CI and needs a baseline before team scale.

## Procedure (analysis-first, then materialize)

### 1. Scan & analyze (do NOT skip)
- List top-level dirs; `find` file-type counts (`*.ts`, `*.tsx`, `*.vue`, `*.js`) excluding
  `node_modules` to get the *real* size (the raw subtree count includes `node_modules`).
- Read `package.json` (scripts + deps + `type`), `tsconfig.json`, build/test configs
  (`vite.config.ts`, `vitest.config.ts`, `*.config.*`).
- Detect existing tooling: `ls -a | grep -iE "eslint|prettier|commitlint|husky|editorconfig"`
  and `git rev-parse --is-inside-work-tree`.
- Read 1–2 representative source + test files to judge code quality and style
  (quotes, semicolons, trailing commas) so Prettier config matches the *existing* style and
  avoids a huge first-format diff.
- Capture architecture highlights and risk points (e.g. a deterministic engine, a no-network
  product rule, UI layer with no tests).

### 2. Generate the init config document (the primary deliverable)
Write a single `INIT.md` at the project root containing exactly these sections:
1. **Tech stack overview** — matrix (lang/framework/build/state/storage/test/pm) + module map +
   architecture highlights + risk points.
2. **Code standards & quality gates** — tool matrix, key config points, the "gate pass criteria"
   (lint 0 error, format check, typecheck, coverage ≥ threshold, build green, conventional commit),
   and local usage commands.
3. **Team skill-improvement path** — phased (L0→L3) with exercises tied to *this* project.
4. **Senior-developer intervention checkpoints** — mandatory sign-off files (e.g. determinism /
   config-schema / public types / cross-module stores / deps) and architecture-review triggers
   (new language direction, any network dependency, new rule family, storage change, perf budget
   breach) + a review checklist.
5. **CI init advice** — pipeline stages, branch protection, gate-to-CI mapping, advanced steps
   (coverage report, preview deploy, semantic-release, dep audit, component tests), landing checklist.

### 3. Materialize the turnkey config files (so the init is actionable, not just a report)
Write these into the project root (copy templates from `references/`):
- `.editorconfig`, `.gitignore`, `.nvmrc` (Node major version)
- `.prettierrc.json`, `.prettierignore`
- `eslint.config.js` (ESLint 9 **flat config** + `typescript-eslint` + `react-hooks` +
  `react-refresh`; `no-unused-vars` → warn with `_` ignore; `no-console`/`no-explicit-any` → warn)
- `commitlint.config.js` (Conventional Commits, `scope-enum` limited to the project's modules)
- `.lintstagedrc.json` (stage-only `eslint --fix` + `prettier --write`)
- `.husky/pre-commit` (`lint-staged`) and `.husky/commit-msg` (`commitlint --edit`);
  `chmod +x` both after writing.
- `.github/workflows/ci.yml` — single job running the 5 gates (see `references/ci.yml`).

### 4. Wire scripts, tsconfig, vitest
- `package.json`: add scripts `lint`, `lint:fix`, `format`, `format:check`, `typecheck`,
  `test:cov`, `prepare: husky`; add devDependencies (ESLint 9, `typescript-eslint` 8,
  `eslint-plugin-react-hooks` 5, `eslint-plugin-react-refresh`, `globals`, Prettier 3, husky 9,
  lint-staged 15, `@commitlint/cli` + `config-conventional` 19, `@vitest/coverage-v8`).
- `tsconfig.json`: promote `noUnusedLocals` / `noUnusedParameters` to `true`; add `noImplicitReturns: true`.
- `vitest.config.ts`: add `coverage` with `provider: 'v8'`, `include: ['src/**/*.{ts,tsx}']`,
  `exclude` entrypoints, and `thresholds` (e.g. statements 80 / branches 75 / functions 80 / lines 80).

### 5. Communicate the landing checklist (do NOT run destructive git ops)
List (do not execute unless asked): `git init`, `npm install` (auto `prepare`),
`lint:fix` + `format` to unify existing code, fix `typecheck` surfaced unused vars,
`test:cov` to confirm thresholds, enable `main` branch protection + CI.

## Key decisions & pitfalls
- **Match Prettier to existing style** (single quotes / semicolons / `trailingComma: all` /
  `printWidth: 100`). This prevents a noisy first-format diff and team friction.
- **ESLint 9 flat config only** — legacy `.eslintrc` is deprecated. Use `typescript-eslint` with
  `tseslint.config(...)`. Keep `no-unused-vars` as `warn` (the hard gate lives in `tsconfig`) to
  avoid double-blocking.
- **Enabling `noUnusedLocals` may surface historical issues** — treat as "gate exposing problems,"
  not new bugs; flag for a day-one cleanup led by the tech lead.
- **Never run `rm`/force git on personal dirs or without consent.** Scanning is read-only; wiring
  configs only *adds* new files and edits `package.json`/`tsconfig`/`vitest.config`.
- **No network during install** is common; state that `npm install` must run in a networked env and
  CI uses `npm ci`.

## Bundled resources
- `references/eslint.config.js` — ready ESLint 9 flat config.
- `references/prettier-commitlint.md` — Prettier + commitlint + lint-staged + husky templates.
- `references/ci.yml` — GitHub Actions quality-gate workflow.
- `references/senior-checkpoints.md` — template for senior sign-off files & architecture-review triggers.
